# Kobi > 2025-05-04 10:02pm
https://universe.roboflow.com/kobi-klh6p/kobi

Provided by a Roboflow user
License: CC BY 4.0

