# Kobi > 2025-05-07 10:22pm
https://universe.roboflow.com/kobi-klh6p/kobi

Provided by a Roboflow user
License: CC BY 4.0

